There are **3** line intersections. 
