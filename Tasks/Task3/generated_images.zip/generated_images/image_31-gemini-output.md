There is **one** line intersection in the image where the blue and red lines cross. 
