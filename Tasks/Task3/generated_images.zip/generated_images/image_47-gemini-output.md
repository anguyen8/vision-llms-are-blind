There is only **one** line intersection in the image. 
