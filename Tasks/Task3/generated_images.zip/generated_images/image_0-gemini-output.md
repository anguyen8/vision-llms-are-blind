There are **two** line intersections in the image. 
