There is **one** line intersection in the image where the red and blue lines cross. 
