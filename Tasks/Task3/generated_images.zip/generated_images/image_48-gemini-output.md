There is **one** line intersection in the image. The blue and red lines cross at a single point. 
