There are **three** line intersections in the image. 
