There is **one** line intersection in the image. 
