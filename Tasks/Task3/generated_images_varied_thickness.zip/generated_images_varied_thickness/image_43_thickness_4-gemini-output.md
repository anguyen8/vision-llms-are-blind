There's **one** point where the red and blue lines intersect. 
