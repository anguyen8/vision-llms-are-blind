There is only **one** line intersection in the image. The red and blue lines cross each other a single time. 
