There are **2** line intersections in the image. 
