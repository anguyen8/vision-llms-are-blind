There are **zero** line intersections in the image. The lines are in separate planes and do not cross. 
