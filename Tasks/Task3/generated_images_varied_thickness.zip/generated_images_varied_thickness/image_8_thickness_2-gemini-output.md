There's only **one** point where the red and blue lines intersect. 
