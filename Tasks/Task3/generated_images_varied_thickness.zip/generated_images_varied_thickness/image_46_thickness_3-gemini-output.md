There is **one** line intersection in the image. The two segments of the blue line intersect. 
