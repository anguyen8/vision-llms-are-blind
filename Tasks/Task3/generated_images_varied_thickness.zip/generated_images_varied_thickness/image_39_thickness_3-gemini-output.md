There are **zero** line intersections in the image. The lines are drawn to give the illusion of intersection, but they are not actually crossing. 
