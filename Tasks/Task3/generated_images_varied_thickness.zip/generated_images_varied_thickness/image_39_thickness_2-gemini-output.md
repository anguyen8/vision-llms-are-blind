There are **zero** line intersections in the image. The lines do not cross each other. 
