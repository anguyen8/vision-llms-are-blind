There is **one** line intersection where the red and blue lines cross. 
