There is **one** line intersection where the two red lines meet the blue line. 
