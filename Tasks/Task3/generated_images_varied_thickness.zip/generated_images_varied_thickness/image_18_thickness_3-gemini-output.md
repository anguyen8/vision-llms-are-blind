There is **one** line intersection in the image. The two lines forming a 'V' shape intersect at their lowest point. 
