There are **zero** line intersections in the image. The lines are in the same plane but they do not cross each other. 
