There is **one** point where the red and blue lines intersect. 
