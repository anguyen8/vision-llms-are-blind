There's only **one** point where the lines intersect. 
