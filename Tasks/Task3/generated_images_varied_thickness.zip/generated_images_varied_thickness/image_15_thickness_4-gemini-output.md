There is **one** line intersection in the image. The red and blue lines cross over each other once. 
