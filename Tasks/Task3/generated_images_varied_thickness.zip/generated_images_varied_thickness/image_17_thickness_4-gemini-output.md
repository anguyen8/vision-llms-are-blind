There is **one** line intersection in the image. The two blue lines intersect with each other, and the two red lines intersect with a blue one at the same point. 
