There are **zero** line intersections in the image. The lines are drawn in a way that they do not cross each other. 
