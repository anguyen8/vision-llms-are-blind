There are **zero** line intersections in the image. The lines are drawn to give the impression of crossing, but they do not actually intersect. 
