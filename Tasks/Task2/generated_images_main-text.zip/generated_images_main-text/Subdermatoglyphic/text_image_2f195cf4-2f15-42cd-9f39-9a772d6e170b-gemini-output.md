The letter **p** is circled. 
