The letter "b" is being circled. 
