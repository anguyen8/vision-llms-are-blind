The letter "S" is being circled. 
