The letter **y** is being circled. 
