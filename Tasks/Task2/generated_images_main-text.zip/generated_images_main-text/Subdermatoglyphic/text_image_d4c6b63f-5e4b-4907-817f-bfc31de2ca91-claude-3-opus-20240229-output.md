## Image Description
The letter 'c' at the end of "Subdermatoglyphic" is being circled in red in the image.