## Image Description
The letter "r" in "Subdermatoglyphic" is being circled in red.