The letter **p** is being circled. 
