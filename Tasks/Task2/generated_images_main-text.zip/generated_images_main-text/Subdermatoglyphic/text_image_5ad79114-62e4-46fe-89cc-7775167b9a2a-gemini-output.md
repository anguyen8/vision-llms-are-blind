The letter **g** is circled. 
