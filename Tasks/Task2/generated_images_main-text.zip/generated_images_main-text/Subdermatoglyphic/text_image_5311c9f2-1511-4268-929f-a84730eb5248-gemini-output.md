The letter **d** is being circled. 
