## Image Description
The letter 'g' is being circled in the word "Subdermatoglyphic".