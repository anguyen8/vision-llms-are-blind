The letter **g** is being circled. 
