The letter being circled is **y**. 
