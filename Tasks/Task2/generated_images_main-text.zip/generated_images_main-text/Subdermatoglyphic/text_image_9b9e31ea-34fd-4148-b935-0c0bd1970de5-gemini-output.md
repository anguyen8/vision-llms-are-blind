The letter **u** is being circled. 
