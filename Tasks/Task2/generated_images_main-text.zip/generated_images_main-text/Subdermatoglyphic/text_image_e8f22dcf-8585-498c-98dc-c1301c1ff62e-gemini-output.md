The letter **l** is being circled. 
