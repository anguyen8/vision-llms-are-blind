The letter "r" is being circled. 
