The letter **h** is circled. 
