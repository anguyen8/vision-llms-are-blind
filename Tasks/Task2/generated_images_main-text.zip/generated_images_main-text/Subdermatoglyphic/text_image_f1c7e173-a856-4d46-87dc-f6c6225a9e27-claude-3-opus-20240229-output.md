## Image Description
The letter 'p' in 'Subdermatoglyphic' is being circled in red.