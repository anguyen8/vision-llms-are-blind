The letter **O** is circled. 
