The letter **O** is being circled. 
