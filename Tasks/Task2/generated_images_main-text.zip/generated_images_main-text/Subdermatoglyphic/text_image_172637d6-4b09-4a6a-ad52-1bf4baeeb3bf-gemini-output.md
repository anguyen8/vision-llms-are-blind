The letter **u** is circled. 
