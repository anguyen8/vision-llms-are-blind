The letter **y** is circled. 
