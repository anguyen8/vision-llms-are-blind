The letter **S** is circled. 
