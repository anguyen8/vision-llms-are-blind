The letter **i** is being circled. 
