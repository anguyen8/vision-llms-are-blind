The letter **e** is circled. 
