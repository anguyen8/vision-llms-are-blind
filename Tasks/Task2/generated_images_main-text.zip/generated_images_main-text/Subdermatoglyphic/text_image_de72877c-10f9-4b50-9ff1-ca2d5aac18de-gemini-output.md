The letter circled is **h**. 
