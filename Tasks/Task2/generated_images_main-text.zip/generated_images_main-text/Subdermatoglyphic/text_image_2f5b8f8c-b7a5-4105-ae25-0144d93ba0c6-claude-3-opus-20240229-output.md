## Image Description
The letter 'y' in 'Subdermatoglyphic' is being circled in red.