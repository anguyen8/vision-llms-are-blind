The letter **h** is being circled. 
