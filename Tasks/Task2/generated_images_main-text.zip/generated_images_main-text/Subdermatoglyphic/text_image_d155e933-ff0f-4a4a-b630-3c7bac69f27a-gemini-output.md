The letter **C** is circled. 
