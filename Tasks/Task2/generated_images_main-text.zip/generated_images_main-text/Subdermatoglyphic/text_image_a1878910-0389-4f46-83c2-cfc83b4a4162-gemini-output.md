The letter **b** is circled. 
