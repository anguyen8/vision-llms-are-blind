The letter **t** is circled. 
