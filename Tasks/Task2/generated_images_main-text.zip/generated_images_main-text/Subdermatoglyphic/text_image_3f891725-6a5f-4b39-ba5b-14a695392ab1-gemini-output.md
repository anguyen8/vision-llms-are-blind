The letter **C** is being circled. 
