The letter **e** is being circled. 
