The letter **m** is circled. 
