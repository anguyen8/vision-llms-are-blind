The letter **o** is being circled. 
