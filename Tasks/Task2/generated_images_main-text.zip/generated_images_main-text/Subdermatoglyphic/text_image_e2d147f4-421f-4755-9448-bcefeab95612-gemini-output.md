The letter **l** is circled. 
