The letter **d** is circled. 
