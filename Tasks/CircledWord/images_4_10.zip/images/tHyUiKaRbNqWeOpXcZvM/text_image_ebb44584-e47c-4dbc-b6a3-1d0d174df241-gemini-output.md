The circled letter is **i**. 
