The letter **R** is circled. 
