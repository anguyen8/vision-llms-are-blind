The letter **K** is circled. 
