The circled character is **@**. 
