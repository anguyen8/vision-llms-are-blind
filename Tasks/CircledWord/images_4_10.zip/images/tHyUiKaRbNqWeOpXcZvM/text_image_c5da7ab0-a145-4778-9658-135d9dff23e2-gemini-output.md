The letter **R** is being circled. 
