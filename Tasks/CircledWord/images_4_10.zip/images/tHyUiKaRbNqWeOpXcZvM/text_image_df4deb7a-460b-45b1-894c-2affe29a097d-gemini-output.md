The letter **N** is circled. 
