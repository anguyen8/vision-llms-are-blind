The letter **i** is circled. 
