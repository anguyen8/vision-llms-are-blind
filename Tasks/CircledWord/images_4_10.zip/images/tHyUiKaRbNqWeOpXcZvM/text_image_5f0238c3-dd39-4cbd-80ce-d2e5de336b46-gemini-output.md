The letter "a" is circled. 
