The letter **N** is being circled. 
