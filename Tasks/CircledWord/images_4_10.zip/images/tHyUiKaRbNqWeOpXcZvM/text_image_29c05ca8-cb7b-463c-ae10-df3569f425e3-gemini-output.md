The circled letter is **a**. 
