The letter **K** is being circled. 
