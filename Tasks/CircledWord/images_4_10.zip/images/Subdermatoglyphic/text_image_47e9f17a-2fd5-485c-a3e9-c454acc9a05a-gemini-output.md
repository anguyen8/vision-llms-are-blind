The letter **r** is circled. 
