The letter being circled is **a**. 
