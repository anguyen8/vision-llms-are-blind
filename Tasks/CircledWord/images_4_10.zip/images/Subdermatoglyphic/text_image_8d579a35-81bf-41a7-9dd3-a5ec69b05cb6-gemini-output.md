The letter "o" is circled. 
