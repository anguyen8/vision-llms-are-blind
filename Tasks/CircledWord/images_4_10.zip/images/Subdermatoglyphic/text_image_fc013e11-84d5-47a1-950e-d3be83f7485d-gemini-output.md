The letter **t** is being circled. 
