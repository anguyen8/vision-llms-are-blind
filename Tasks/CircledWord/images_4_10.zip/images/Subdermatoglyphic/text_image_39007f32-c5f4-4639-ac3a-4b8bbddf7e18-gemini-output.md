The letter **m** is being circled. 
