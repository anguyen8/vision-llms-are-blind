The letter **a** is being circled. 
